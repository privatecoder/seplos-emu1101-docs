@echo off
reg add "HKCU\Control Panel\International" /t REG_SZ /v sDecimal  /d , /f
reg add "HKCU\Control Panel\International" /t REG_SZ /v sThousand /d . /f

start BatteryMonitor.exe    

reg add "HKCU\Control Panel\International" /t REG_SZ /v sDecimal  /d . /f
reg add "HKCU\Control Panel\International" /t REG_SZ /v sThousand /d , /f